<template>
<div class="col-lg-8">
									<div class="card">
										<div class="card-header">
											<h5 class="card-title">Activity</h5>
										</div>
										<div class="card-body card-body-height">
											<ul class="activity-feed">
												<li class="feed-item">
													<div class="feed-date">Nov 16</div>
													<span class="feed-text"><router-link to="/profile">Brian Johnson</router-link> has paid the invoice <router-link to="/view-invoice">"#DF65485"</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Nov 7</div>
													<span class="feed-text"><router-link to="/profile">Marie Canales</router-link>  has accepted your estimate <router-link to="/view-estimate">#GTR458789</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Oct 24</div>
													<span class="feed-text">New expenses added <router-link to="/expenses">"#TR018756</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Oct 24</div>
													<span class="feed-text">New expenses added <router-link to="/expenses">"#TR018756</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Oct 24</div>
													<span class="feed-text">New expenses added <router-link to="/expenses">"#TR018756</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Oct 24</div>
													<span class="feed-text">New expenses added <router-link to="/expenses">"#TR018756</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Oct 24</div>
													<span class="feed-text">New expenses added <router-link to="/expenses">"#TR018756</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Jan 27</div>
													<span class="feed-text"><router-link to="/profile">Robert Martin</router-link> gave a review for <router-link to="/product-details">"Dell Laptop"</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Jan 14</div>
													<span class="feed-text">New customer registered <router-link to="/profile">"Tori Carter"</router-link></span>
												</li>
											</ul>
										</div>
									</div>
								</div>
</template>