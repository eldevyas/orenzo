<template>
<!-- Page Header -->
<div class="page-header">
    <div class="row">
        <div class="col-sm-12">
            <h3 class="page-title">Form Wizard</h3>
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><router-link to="inde">Dashboard</router-link></li>
                <li class="breadcrumb-item active">Form Wizard</li>
            </ul>
        </div>
    </div>
</div>
<!-- /Page Header -->
</template>