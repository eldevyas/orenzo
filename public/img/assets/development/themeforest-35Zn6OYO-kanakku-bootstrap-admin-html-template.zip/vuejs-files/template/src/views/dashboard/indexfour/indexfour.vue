<template>
    	<!-- Main Wrapper -->
		<div class="main-wrapper">

			<indexfourheader></indexfourheader>

            <indexfoursidebar></indexfoursidebar>

			<!-- Page Wrapper -->
			<div class="page-wrapper-three">
				<div class="content container-fluid">

					<indextwowidget></indextwowidget>
					
					<indextwograph></indextwograph>

					<div class="row">
						
						<indextwoinvoice></indextwoinvoice>

						<indextwoestimate></indextwoestimate>

					</div>
				</div>
			</div>
			<!-- /Page Wrapper -->

            </div>
		<!-- /Main Wrapper -->
</template>