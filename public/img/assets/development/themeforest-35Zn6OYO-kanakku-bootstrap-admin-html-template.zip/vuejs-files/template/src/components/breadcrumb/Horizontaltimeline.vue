<template>
<!-- Page Header -->
<div class="page-header">
    <div class="row">
        <div class="col-sm-12">
            <h3 class="page-title">Horizontal Timeline</h3>
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><router-link to="inde">Dashboard</router-link></li>
                <li class="breadcrumb-item active">Horizontal Timeline</li>
            </ul>
        </div>
    </div>
</div>
<!-- /Page Header -->
</template>