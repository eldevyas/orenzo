<template>
        <router-link to="/index" class="logo">
            <img src="../assets/img/logo.png" alt="Logo">
        </router-link>
        <router-link to="/index" class="white-logo">
            <img src="../assets/img/logo-white.png" alt="Logo">
        </router-link>
        <router-link to="/index" class="logo logo-small">
            <img src="../assets/img/logo-small.png" alt="Logo" width="30" height="30">
        </router-link>
</template>