<template>
<!-- Invoice Item -->
									<div class="invoice-item invoice-table-wrap">
										<div class="row">
											<div class="col-md-12">
												<div class="table-responsive">
													<table class="invoice-table table table-bordered">
														<thead>
															<tr>
																<th>Description</th>
																<th class="text-center">Quantity</th>
																<th class="text-center">VAT</th>
																<th class="text-end">Total</th>
															</tr>
														</thead>
														<tbody>
															<tr>
																<td>General Consultation</td>
																<td class="text-center">1</td>
																<td class="text-center">$0</td>
																<td class="text-end">$100</td>
															</tr>
															<tr>
																<td>Video Call Booking</td>
																<td class="text-center">1</td>
																<td class="text-center">$0</td>
																<td class="text-end">$250</td>
															</tr>
														</tbody>
													</table>
												</div>
											</div>
											<div class="col-md-6 col-xl-4 ms-auto">
												<div class="table-responsive">
													<table class="invoice-table-two table">
														<tbody>
														<tr>
															<th>Subtotal:</th>
															<td><span>$350</span></td>
														</tr>
														<tr>
															<th>Discount:</th>
															<td><span>-10%</span></td>
														</tr>
														<tr>
															<th>Total Amount:</th>
															<td><span>$315</span></td>
														</tr>
														</tbody>
													</table>
												</div>
											</div>
										</div>
									</div>
									<!-- /Invoice Item -->
</template>