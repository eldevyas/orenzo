<template>
<div class="card-body">
									<form action="#">
										<div class="form-group row">
											<label class="col-form-label col-lg-2">Left Dropdown Text Addons</label>
											<div class="col-lg-10">
												<div class="input-group">
													<button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">Dropdown</button>
													<ul class="dropdown-menu">
														<li><a class="dropdown-item" href="javascript:void(0)">Action</a></li>
														<li><a class="dropdown-item" href="javascript:void(0)">Another action</a></li>
														<li><a class="dropdown-item" href="javascript:void(0)">Something else here</a></li>
														<li><hr class="dropdown-divider"></li>
														<li><a class="dropdown-item" href="javascript:void(0)">Separated link</a></li>
													</ul>
													<input type="text" class="form-control" aria-label="Text input with dropdown button">
												</div>
											</div>
										</div>

										<div class="form-group row mb-0">
											<label class="col-form-label col-lg-2">Right Dropdown Text Addons</label>
											<div class="col-lg-10">
												<div class="input-group">
													<input type="text" class="form-control" aria-label="Text input with dropdown button">
													<button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">Dropdown</button>
													<ul class="dropdown-menu dropdown-menu-end">
														<li><a class="dropdown-item" href="javascript:void(0)">Action</a></li>
														<li><a class="dropdown-item" href="javascript:void(0)">Another action</a></li>
														<li><a class="dropdown-item" href="javascript:void(0)">Something else here</a></li>
														<li><hr class="dropdown-divider"></li>
														<li><a class="dropdown-item" href="javascript:void(0)">Separated link</a></li>
													</ul>
												</div>
											</div>
										</div>
									</form>
								</div>
</template>