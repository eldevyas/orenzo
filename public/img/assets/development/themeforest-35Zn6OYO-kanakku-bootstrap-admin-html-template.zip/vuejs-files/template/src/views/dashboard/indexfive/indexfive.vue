<template>
    	<!-- Main Wrapper -->
		<div class="main-wrapper container">

			<indexfiveheader></indexfiveheader>

            <indexfivesidebar></indexfivesidebar>

			<!-- Page Wrapper -->
			<div class="page-wrapper page-wrapper-four">
				<div class="content container-fluid">

					<indextwowidget></indextwowidget>
					
					<indextwograph></indextwograph>

					<div class="row">
						
						<indextwoinvoice></indextwoinvoice>

						<indextwoestimate></indextwoestimate>

					</div>
				</div>
			</div>
			<!-- /Page Wrapper -->

            </div>
		<!-- /Main Wrapper -->
</template>