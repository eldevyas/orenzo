<template>
    	<!-- Main Wrapper -->
		<div class="main-wrapper">

			<indextwoheader></indextwoheader>

			<indextwosidebar></indextwosidebar>

			<!-- Page Wrapper -->
			<div class="page-wrapper">
				<div class="content container-fluid">

					<indextwowidget></indextwowidget>
					
					<indextwograph></indextwograph>

					<div class="row">
						
						<indextwoinvoice></indextwoinvoice>

						<indextwoestimate></indextwoestimate>

					</div>
				</div>
			</div>
			<!-- /Page Wrapper -->

            </div>
		<!-- /Main Wrapper -->
</template>