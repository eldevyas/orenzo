<template>
    <!-- Page Header -->
    <div class="page-header">
        <div class="row">
            <div class="col">
                <h3 class="page-title">Offcanvas</h3>
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><router-link to="/">Dashboard</router-link></li>
                    <li class="breadcrumb-item active">Components</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /Page Header -->
    </template>