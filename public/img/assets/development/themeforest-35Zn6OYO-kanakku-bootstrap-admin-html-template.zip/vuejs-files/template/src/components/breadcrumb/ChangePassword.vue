<template>
<div class="page-header">
						<div class="row">
							<div class="col-sm-6">
								<h3 class="page-title">Settings</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><router-link to="/">Dashboard</router-link>
									</li>
									<li class="breadcrumb-item active">Change Password</li>
								</ul>
							</div>
						</div>
</div>
</template>