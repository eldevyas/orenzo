<template>
<div class="card-body">
									<form action="#">
										<div class="form-group row">
											<label class="col-form-label col-lg-2">Checkbox</label>
											<div class="col-lg-10">
												<div class="input-group">
													<div class="input-group-text">
														<input class="form-check-input" type="checkbox" value="" aria-label="Checkbox for following text input">
													</div>
													<input type="text" class="form-control" aria-label="Text input with checkbox">
												</div>
											</div>
										</div>
										<div class="form-group row mb-0">
											<label class="col-form-label col-lg-2">Radio</label>
											<div class="col-lg-10">
												<div class="input-group">
													<div class="input-group-text">
														<input class="form-check-input" type="radio" value="" aria-label="Radio button for following text input">
													</div>
													<input type="text" class="form-control" aria-label="Text input with radio button">
												</div>
											</div>
										</div>
									</form>
								</div>
</template>