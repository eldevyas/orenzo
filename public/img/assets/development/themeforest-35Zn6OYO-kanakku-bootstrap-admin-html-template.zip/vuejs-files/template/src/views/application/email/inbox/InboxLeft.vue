<template>
<div class="col-lg-3 col-md-4">
							<div class="compose-btn">
								<a href="javascript:void(0);" class="btn btn-primary btn-block w-100">
								Compose
								</a>
							</div>
							<ul class="inbox-menu">
								<li class="active">
									<a href="javascript:void(0)"><i class="fas fa-download"></i> Inbox <span class="mail-count">(5)</span></a>
								</li>
								<li>
									<a href="javascript:void(0)"><i class="far fa-star"></i> Important</a>
								</li>
								<li>
									<a href="javascript:void(0)"><i class="far fa-paper-plane"></i> Sent Mail</a>
								</li>
								<li>
									<a href="javascript:void(0)"><i class="far fa-file-alt"></i> Drafts <span class="mail-count">(13)</span></a>
								</li>
								<li>
									<a href="javascript:void(0)"><i class="far fa-trash-alt"></i> Trash</a>
								</li>
							</ul>
						</div>
</template>