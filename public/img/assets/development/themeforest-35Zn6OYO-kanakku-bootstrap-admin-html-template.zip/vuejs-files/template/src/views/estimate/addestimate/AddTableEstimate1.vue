<template>
<div class="table-responsive mt-4">
											<table class="table table-stripped table-center table-hover">
												<thead></thead>
												<tbody>
													<tr>
														<td></td>
														<td></td>
														<td></td>
														<td class="text-end">Sub Total</td>
														<td class="text-end">0</td>
													</tr>
													<tr>
														<td></td>
														<td></td>
														<td></td>
														<td class="text-end">Discount</td>
														<td class="text-end">0</td>
													</tr>
													<tr>
														<td></td>
														<td></td>
														<td></td>
														<td class="text-end">Total</td>
														<td class="text-end">0</td>
													</tr>
												</tbody>
											</table>
										</div>
</template>