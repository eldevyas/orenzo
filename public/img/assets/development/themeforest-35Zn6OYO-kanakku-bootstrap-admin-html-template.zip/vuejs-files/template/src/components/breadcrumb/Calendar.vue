<template>
<!-- Page Header -->
					<div class="page-header">
						<div class="row align-items-center">
							<div class="col">
								<h3 class="page-title">Calendar</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><router-link to="/">Dashboard</router-link></li>
									<li class="breadcrumb-item active">Calendar</li>
								</ul>
							</div>
							<div class="col-auto text-right float-right ms-auto">
							<a href="javascript:void(0)" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#add_event">Create Event</a>
							</div>
						</div>
					</div>
					<!-- /Page Header -->
</template>