<template>
<div class="table-responsive mt-4">
											<table class="table table-hover">
												<thead>
													<tr>
														<th>Items</th>
														<th>Quantity</th>
														<th>Price</th>
														<th>Amount</th>
														<th>Actions</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td>
															<input type="text" class="form-control">
														</td>
														<td>
															<input type="text" class="form-control">
														</td>
														<td>
															<input type="text" class="form-control">
														</td>
														<td>
															<input type="text" class="form-control" disabled>
														</td>
														<td class="add-remove text-end">
															<i class="fas fa-plus-circle"></i > <i class="fas fa-minus-circle"></i> 
														</td>
													</tr>
													<tr>
														<td>
															<input type="text" class="form-control">
														</td>
														<td>
															<input type="text" class="form-control">
														</td>
														<td>
															<input type="text" class="form-control">
														</td>
														<td>
															<input type="text" class="form-control" disabled>
														</td>
														<td class="add-remove text-end">
															<i class="fas fa-plus-circle"></i > <i class="fas fa-minus-circle"></i> 
														</td>
													</tr>
												</tbody>
											</table>
										</div>
</template>